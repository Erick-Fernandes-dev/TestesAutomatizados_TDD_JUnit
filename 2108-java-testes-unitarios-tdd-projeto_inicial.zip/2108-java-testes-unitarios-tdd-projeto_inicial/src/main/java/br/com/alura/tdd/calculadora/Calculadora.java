package br.com.alura.tdd.calculadora;

public class Calculadora {
	
	public int somar(int a, int b) {
		return a + b;
	}

}
